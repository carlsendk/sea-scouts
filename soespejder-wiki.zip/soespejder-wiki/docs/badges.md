
# Mærker

Det Danske Spejderkorps tilbyder en lang række mærker, som kan støtte læring i sejlads og friluftsliv. Her er et udvalg, der passer til søspejd.

## Søsportsmærker

- **Småbådssejler** – intro til sejlads i små joller.  
- **Gast** – lær om teamwork, trim og manøvrer på større både.  
- **Kaptajn** – planlægning, navigation og ansvar på vandet.  
- **Sømil** – log dine sejlture og nå et bestemt antal sømil.  
- **Svømmer** – sikkerhed i vandet; bestå en svømmeprøve.  
- **Kano / Kajak** – padleteknik og vandvett.

## Friluftsmærker

- **Bål** – lær at tænde bål og bålvett.  
- **Bålkok** – madlavning på bål.  
- **Kniv, Sav & Økse** – sikkerhed og teknik med skærende værktøj.  
- **Førstehjælp** – basal førstehjælp.  
- **Klar dig selv** – pakning, madlavning og selvstændighed på tur.  

Tilføj mærker efter behov og aldersspor. Husk at lade spejderne være med til at vælge hvilke mærker de vil arbejde hen imod.
